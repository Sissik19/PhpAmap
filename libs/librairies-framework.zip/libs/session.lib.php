<?php

function user_is_connected() {
	return false ;
}

?>